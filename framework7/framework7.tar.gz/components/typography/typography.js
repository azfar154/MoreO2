export default {
  name: 'typography',
};
